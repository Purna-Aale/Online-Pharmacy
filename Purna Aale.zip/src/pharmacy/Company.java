
package pharmacy;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.regex.*;
import javax.swing.ImageIcon;
import net.proteanit.sql.DbUtils;
import javax.swing.table.DefaultTableModel;

public class Company extends javax.swing.JFrame {
    Connection conn=null;
    PreparedStatement pst=null;
    public Company() {
        initComponents();
        imageicon();
        companylist();
    }
    public void imageicon()
    {
        ImageIcon i=new ImageIcon(ClassLoader.getSystemResource("icon/d.png"));
        Image img=i.getImage();
        Image imageScale=img.getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);    
        ImageIcon scaledIcon=new ImageIcon(imageScale);
        logo.setIcon(scaledIcon);
        
    }
     public void companylist() {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", "");
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from companymanage");
            companylist.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException exp) {
            exp.printStackTrace();
        }

    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelid = new javax.swing.JLabel();
        jLabelname = new javax.swing.JLabel();
        jLabeladdress = new javax.swing.JLabel();
        jLabelexperience = new javax.swing.JLabel();
        jLabelphonenbr = new javax.swing.JLabel();
        jTextFieldid = new javax.swing.JTextField();
        jTextFieldname = new javax.swing.JTextField();
        jTextFieldaddress = new javax.swing.JTextField();
        jTextFieldexperience = new javax.swing.JTextField();
        jTextFieldphonenbr = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        companylist = new javax.swing.JTable();
        jButtonadd = new javax.swing.JButton();
        jButtonupdate = new javax.swing.JButton();
        jButtondelete = new javax.swing.JButton();
        jButtonclear = new javax.swing.JButton();
        jLabelcompanylist = new javax.swing.JLabel();
        logo = new javax.swing.JLabel();
        back = new javax.swing.JLabel();
        exit = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 0)));

        jLabelid.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelid.setForeground(new java.awt.Color(0, 102, 0));
        jLabelid.setText("ID:");

        jLabelname.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelname.setForeground(new java.awt.Color(0, 102, 0));
        jLabelname.setText("NAME:");

        jLabeladdress.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabeladdress.setForeground(new java.awt.Color(0, 102, 0));
        jLabeladdress.setText("ADDRESS:");

        jLabelexperience.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelexperience.setForeground(new java.awt.Color(0, 102, 0));
        jLabelexperience.setText("EXPERIENCE:");

        jLabelphonenbr.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelphonenbr.setForeground(new java.awt.Color(0, 102, 0));
        jLabelphonenbr.setText("PHONE NBR:");

        jTextFieldid.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldid.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldid.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldidKeyTyped(evt);
            }
        });

        jTextFieldname.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldname.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextFieldnameKeyPressed(evt);
            }
        });

        jTextFieldaddress.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldaddress.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldaddress.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextFieldaddressKeyPressed(evt);
            }
        });

        jTextFieldexperience.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldexperience.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldexperience.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldexperienceKeyTyped(evt);
            }
        });

        jTextFieldphonenbr.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldphonenbr.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldphonenbr.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextFieldphonenbrKeyPressed(evt);
            }
        });

        companylist.setForeground(new java.awt.Color(0, 102, 0));
        companylist.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "COMID", "COMNAME", "COMADDRESS", "COMEXPERIENCE", "COMPHONENBR"
            }
        ));
        companylist.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                companylistMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(companylist);

        jButtonadd.setBackground(new java.awt.Color(0, 102, 0));
        jButtonadd.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButtonadd.setForeground(new java.awt.Color(255, 255, 255));
        jButtonadd.setText("ADD");
        jButtonadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonaddActionPerformed(evt);
            }
        });

        jButtonupdate.setBackground(new java.awt.Color(0, 102, 0));
        jButtonupdate.setForeground(new java.awt.Color(255, 255, 255));
        jButtonupdate.setText("UPDATE");
        jButtonupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonupdateActionPerformed(evt);
            }
        });

        jButtondelete.setBackground(new java.awt.Color(0, 102, 0));
        jButtondelete.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButtondelete.setForeground(new java.awt.Color(255, 255, 255));
        jButtondelete.setText("DELETE");
        jButtondelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtondeleteActionPerformed(evt);
            }
        });

        jButtonclear.setBackground(new java.awt.Color(0, 102, 0));
        jButtonclear.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButtonclear.setForeground(new java.awt.Color(255, 255, 255));
        jButtonclear.setText("CLEAR");
        jButtonclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonclearActionPerformed(evt);
            }
        });

        jLabelcompanylist.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelcompanylist.setForeground(new java.awt.Color(0, 102, 0));
        jLabelcompanylist.setText("COMPANYLIST");

        back.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        back.setForeground(new java.awt.Color(0, 102, 0));
        back.setText("Back");
        back.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backMouseClicked(evt);
            }
        });

        exit.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        exit.setForeground(new java.awt.Color(0, 102, 0));
        exit.setText("x");
        exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabelcompanylist)
                .addGap(344, 344, 344))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 623, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelid)
                                    .addComponent(jLabelname)
                                    .addComponent(jLabeladdress))
                                .addGap(27, 27, 27)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(48, 48, 48)
                                        .addComponent(jButtonadd)
                                        .addGap(27, 27, 27)
                                        .addComponent(jButtonupdate)
                                        .addGap(43, 43, 43)
                                        .addComponent(jButtondelete))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jTextFieldname, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                                            .addComponent(jTextFieldid)
                                            .addComponent(jTextFieldaddress))
                                        .addGap(124, 124, 124)
                                        .addComponent(jLabelexperience))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(264, 264, 264)
                                        .addComponent(jLabelphonenbr)))
                                .addGap(10, 10, 10)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jButtonclear)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jTextFieldphonenbr, javax.swing.GroupLayout.DEFAULT_SIZE, 146, Short.MAX_VALUE)
                                        .addComponent(jTextFieldexperience)))))
                        .addGap(0, 98, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(back, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(exit, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(exit)
                        .addGap(18, 18, 18)
                        .addComponent(back)))
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelid)
                    .addComponent(jTextFieldid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldexperience, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelexperience))
                .addGap(3, 3, 3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelname)
                    .addComponent(jTextFieldname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(1, 1, 1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelphonenbr)
                    .addComponent(jTextFieldphonenbr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabeladdress)
                    .addComponent(jTextFieldaddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonadd)
                    .addComponent(jButtonupdate)
                    .addComponent(jButtondelete)
                    .addComponent(jButtonclear))
                .addGap(18, 18, 18)
                .addComponent(jLabelcompanylist)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitMouseClicked

    private void backMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backMouseClicked
        Adminhome obj=new Adminhome();
        obj.setVisible(true);
        dispose();

    }//GEN-LAST:event_backMouseClicked

    private void jButtonclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonclearActionPerformed
        jTextFieldid.setText(null);
        jTextFieldname.setText(null);
        jTextFieldaddress.setText(null);
        jTextFieldexperience.setText(null);
        jTextFieldphonenbr.setText(null);
    }//GEN-LAST:event_jButtonclearActionPerformed

    private void jButtondeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtondeleteActionPerformed
        if (jTextFieldid.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter the company id to be deleted.");
        } else {
            try {
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", "");
                String COMID = jTextFieldid.getText();
                String Deletequery = "Delete from pharmacy.companymanage where COMID =" +COMID;
                Statement delete = conn.createStatement();
                delete.executeUpdate(Deletequery);
                companylist();
                JOptionPane.showMessageDialog(this, "Deleted successfully");
            } catch (SQLException exp) {
                exp.printStackTrace();
            }
        }
    }//GEN-LAST:event_jButtondeleteActionPerformed

    private void jButtonupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonupdateActionPerformed
        if (jTextFieldid.getText().isEmpty() || jTextFieldname.getText().isEmpty() || jTextFieldaddress.getText().isEmpty() || jTextFieldexperience.getText().isEmpty()|| jTextFieldphonenbr.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Missing information.");
        } else {
            try {

                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", "");
                String UpdateQuery = "Update pharmacy.companymanage set COMNAME='"+jTextFieldname.getText()+"'"+",COMADDRESS='"+jTextFieldaddress.getText()+"'"+",COMEXPERIENCE='"+jTextFieldexperience.getText()+"'"+",COMPHONENBR='"+jTextFieldphonenbr.getText()+"'"+"where COMID="+jTextFieldid.getText();
                Statement smt=conn.createStatement();
                smt.executeUpdate(UpdateQuery);
                companylist();
                JOptionPane.showMessageDialog(this, "updated successfully.");
            } catch (SQLException exp) {
                exp.printStackTrace();
            }

        }
    }//GEN-LAST:event_jButtonupdateActionPerformed

    private void jButtonaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonaddActionPerformed
        try{
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/pharmacy","root","");
            String query = "INSERT INTO `companymanage`(`COMID`, `COMNAME`, `COMADDRESS`, `COMEXPERIENCE`, `COMPHONENBR`) VALUES (?, ?, ?,?,?)";
            pst=conn.prepareStatement(query);
            pst.setString(1, jTextFieldid.getText());
            pst.setString(2, jTextFieldname.getText());
            pst.setString(3, jTextFieldaddress.getText());
            pst.setString(4, jTextFieldexperience.getText());
            pst.setString(5, jTextFieldphonenbr.getText());
            int row = pst.executeUpdate();
            companylist();
            JOptionPane.showMessageDialog(null,"sucessfully addeded.");
        }

        catch(Exception exp)
        {
            JOptionPane.showMessageDialog(null,exp);
        }
    }//GEN-LAST:event_jButtonaddActionPerformed

    private void companylistMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_companylistMouseClicked
        DefaultTableModel model = (DefaultTableModel) companylist.getModel();
        int Myindex = companylist.getSelectedRow();
        jTextFieldid.setText(model.getValueAt(Myindex, 0).toString());
        jTextFieldname.setText(model.getValueAt(Myindex, 1).toString());
        jTextFieldaddress.setText(model.getValueAt(Myindex, 2).toString());
        jTextFieldexperience.setText(model.getValueAt(Myindex, 3).toString());
        jTextFieldphonenbr.setText(model.getValueAt(Myindex, 4).toString());
        companylist();
    }//GEN-LAST:event_companylistMouseClicked

    private void jTextFieldphonenbrKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldphonenbrKeyPressed
        String PHONENBR=jTextFieldphonenbr.getText();
        int length=PHONENBR.length();
        char c = evt.getKeyChar();
        if(evt.getKeyChar()>='0'&&evt.getKeyChar()<='9')
        {
            if(length<10)
            {
                jTextFieldphonenbr.setEditable(true);
            }
            else{
                jTextFieldphonenbr.setEditable(false);

            }
        }else{
            if(evt.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE ||evt.getExtendedKeyCode()==KeyEvent.VK_DELETE)
            {
                jTextFieldphonenbr.setEditable(true);
            }else{
                jTextFieldphonenbr.setEditable(false);
            }
        }

    }//GEN-LAST:event_jTextFieldphonenbrKeyPressed

    private void jTextFieldexperienceKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldexperienceKeyTyped
        char c = evt.getKeyChar();
        if(!Character.isDigit(c))
        {
            evt.consume();;
        }
    }//GEN-LAST:event_jTextFieldexperienceKeyTyped

    private void jTextFieldaddressKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldaddressKeyPressed
        char c = evt.getKeyChar();
        if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c))
        {
            jTextFieldaddress.setEditable(true);
        }
        else{
            jTextFieldaddress.setEditable(false);

        }
    }//GEN-LAST:event_jTextFieldaddressKeyPressed

    private void jTextFieldnameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldnameKeyPressed
        char c = evt.getKeyChar();
        if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c))
        {
            jTextFieldname.setEditable(true);
        }
        else{
            jTextFieldname.setEditable(false);

        }
    }//GEN-LAST:event_jTextFieldnameKeyPressed

    private void jTextFieldidKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldidKeyTyped
        char c = evt.getKeyChar();
        if(!Character.isDigit(c))
        {
            evt.consume();;
        }
    }//GEN-LAST:event_jTextFieldidKeyTyped

    public static void main(String args[]) {
               java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
         new Company().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel back;
    private javax.swing.JTable companylist;
    private javax.swing.JLabel exit;
    private javax.swing.JButton jButtonadd;
    private javax.swing.JButton jButtonclear;
    private javax.swing.JButton jButtondelete;
    private javax.swing.JButton jButtonupdate;
    private javax.swing.JLabel jLabeladdress;
    private javax.swing.JLabel jLabelcompanylist;
    private javax.swing.JLabel jLabelexperience;
    private javax.swing.JLabel jLabelid;
    private javax.swing.JLabel jLabelname;
    private javax.swing.JLabel jLabelphonenbr;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextFieldaddress;
    private javax.swing.JTextField jTextFieldexperience;
    private javax.swing.JTextField jTextFieldid;
    private javax.swing.JTextField jTextFieldname;
    private javax.swing.JTextField jTextFieldphonenbr;
    private javax.swing.JLabel logo;
    // End of variables declaration//GEN-END:variables
}
