
package pharmacy;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import static jdk.jfr.FlightRecorder.register;

public class Register extends javax.swing.JFrame {

    public Register() {
        initComponents();
        imageicon();
    }
    public void imageicon()
    {
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/d.png"));
        Image img=i1.getImage();
        Image imageScale=img.getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);    
        ImageIcon scaledIcon=new ImageIcon(imageScale);
        logo.setIcon(scaledIcon);
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSlider1 = new javax.swing.JSlider();
        jPanel1 = new javax.swing.JPanel();
        jLabelfullname = new javax.swing.JLabel();
        jLabelusername = new javax.swing.JLabel();
        jLabelpassword = new javax.swing.JLabel();
        jLabelconfirmpassword = new javax.swing.JLabel();
        jLabelemail = new javax.swing.JLabel();
        jLabelphonenbr = new javax.swing.JLabel();
        jLabeladdress = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPasswordFieldpassword = new javax.swing.JPasswordField();
        jPasswordFieldcinfirmpassword = new javax.swing.JPasswordField();
        jTextFieldemail = new javax.swing.JTextField();
        jTextFieldphonenbr = new javax.swing.JTextField();
        jTextFieldaddress = new javax.swing.JTextField();
        jTextFieldfullname = new javax.swing.JTextField();
        jTextFieldusername = new javax.swing.JTextField();
        jButtonback = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButtonclear = new javax.swing.JButton();
        logo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 0)));

        jLabelfullname.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelfullname.setForeground(new java.awt.Color(0, 102, 0));
        jLabelfullname.setText("FULL NAME:");

        jLabelusername.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelusername.setForeground(new java.awt.Color(0, 102, 0));
        jLabelusername.setText("USER NAME:");

        jLabelpassword.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelpassword.setForeground(new java.awt.Color(0, 102, 0));
        jLabelpassword.setText("PASSWORD:");

        jLabelconfirmpassword.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelconfirmpassword.setForeground(new java.awt.Color(0, 102, 0));
        jLabelconfirmpassword.setText("CONFIRM PASSWORD:");

        jLabelemail.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelemail.setForeground(new java.awt.Color(0, 102, 0));
        jLabelemail.setText("EMAIL:");

        jLabelphonenbr.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelphonenbr.setForeground(new java.awt.Color(0, 102, 0));
        jLabelphonenbr.setText("PHONE NBR:");

        jLabeladdress.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabeladdress.setForeground(new java.awt.Color(0, 102, 0));
        jLabeladdress.setText("ADDRESS:");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 102, 0));
        jLabel10.setText("REGISTER PAGE");

        jPasswordFieldpassword.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jPasswordFieldpassword.setForeground(new java.awt.Color(0, 102, 0));

        jPasswordFieldcinfirmpassword.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jPasswordFieldcinfirmpassword.setForeground(new java.awt.Color(0, 102, 0));
        jPasswordFieldcinfirmpassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordFieldcinfirmpasswordActionPerformed(evt);
            }
        });

        jTextFieldemail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldemail.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldemailActionPerformed(evt);
            }
        });
        jTextFieldemail.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldemailKeyReleased(evt);
            }
        });

        jTextFieldphonenbr.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldphonenbr.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldphonenbr.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextFieldphonenbrKeyPressed(evt);
            }
        });

        jTextFieldaddress.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldaddress.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldaddress.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextFieldaddressKeyPressed(evt);
            }
        });

        jTextFieldfullname.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldfullname.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldfullname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldfullnameActionPerformed(evt);
            }
        });
        jTextFieldfullname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextFieldfullnameKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldfullnameKeyReleased(evt);
            }
        });

        jTextFieldusername.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldusername.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldusername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldusernameActionPerformed(evt);
            }
        });

        jButtonback.setBackground(new java.awt.Color(0, 102, 0));
        jButtonback.setForeground(new java.awt.Color(255, 255, 255));
        jButtonback.setText("BACK");
        jButtonback.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonbackMouseClicked(evt);
            }
        });
        jButtonback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonbackActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 102, 0));
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("SUBMIT");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButtonclear.setBackground(new java.awt.Color(0, 102, 0));
        jButtonclear.setForeground(new java.awt.Color(255, 255, 255));
        jButtonclear.setText("CLEAR");
        jButtonclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonclearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(82, 82, 82)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabelusername)
                                    .addComponent(jLabelfullname)
                                    .addComponent(jLabelpassword))
                                .addGap(90, 90, 90)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jTextFieldfullname, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextFieldusername, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPasswordFieldpassword, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelconfirmpassword)
                                    .addComponent(jLabelemail)
                                    .addComponent(jLabelphonenbr)
                                    .addComponent(jLabeladdress))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextFieldaddress, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextFieldphonenbr, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextFieldemail, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPasswordFieldcinfirmpassword, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jButtonback)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButtonclear)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton2))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(108, 108, 108)
                        .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(221, 221, 221)
                        .addComponent(jLabel10)))
                .addContainerGap(104, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldfullname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelfullname))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldusername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelusername))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelpassword)
                    .addComponent(jPasswordFieldpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelconfirmpassword)
                    .addComponent(jPasswordFieldcinfirmpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelemail)
                    .addComponent(jTextFieldemail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelphonenbr)
                    .addComponent(jTextFieldphonenbr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabeladdress)
                    .addComponent(jTextFieldaddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonback)
                    .addComponent(jButtonclear)
                    .addComponent(jButton2))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldusernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldusernameActionPerformed
       
    }//GEN-LAST:event_jTextFieldusernameActionPerformed

    private void jPasswordFieldcinfirmpasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordFieldcinfirmpasswordActionPerformed
       
    }//GEN-LAST:event_jPasswordFieldcinfirmpasswordActionPerformed

    private void jTextFieldemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldemailActionPerformed
        
    }//GEN-LAST:event_jTextFieldemailActionPerformed

    private void jButtonbackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonbackMouseClicked
        // TODO add your handling code here:
        Login obj=new Login();
        obj.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButtonbackMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
   
            String FULLNAME =jTextFieldfullname.getText();
            String USERNAME =jTextFieldusername.getText();
            String PASSWORD =String.valueOf(jPasswordFieldpassword.getText());
            String CONFIRMPASSWORD=String.valueOf(jPasswordFieldcinfirmpassword.getText());
            String EMAIL =jTextFieldemail.getText();
            String PHONENBR=jTextFieldphonenbr.getText();
            String ADDRESS = jTextFieldaddress.getText();
            
            if(FULLNAME.equals(""))
            {
               JOptionPane.showMessageDialog(null,"please enter your full name."); 
            
            }
            
            else if(USERNAME.equals(""))
            {
               JOptionPane.showMessageDialog(null,"please enter your user name."); 
            }
            
            else if(PASSWORD.equals(""))
            {
               JOptionPane.showMessageDialog(null,"please enter your password."); 
            }
            else if(!PASSWORD.equals(CONFIRMPASSWORD))
            {
               JOptionPane.showMessageDialog(null,"please retype your password again."); 
            }
            
            else if(EMAIL.equals(""))
            {
               JOptionPane.showMessageDialog(null,"please enter your email id."); 
            }
            
            else if(PHONENBR.equals(""))
            {
               JOptionPane.showMessageDialog(null,"please enter your phonenbr."); 
            }
            
            else if(ADDRESS.equals(""))
            {
               JOptionPane.showMessageDialog(null,"please enter your address."); 
            }
            else{
            
            PreparedStatement pst;
            String query = "INSERT INTO `register`(`FULLNAME`, `USERNMAE`, `PASSWORD`, `CONFIRMPASSWORD`, `EMAIL`, `PHONENBR`, `ADDRESS`) VALUES (?,?,?,?,?,?,?)";
            try{
            pst=Jdbc1connection.getConnection().prepareStatement(query);
            pst.setString(1, FULLNAME );
            pst.setString(2, USERNAME );
            pst.setString(3, PASSWORD );
            pst.setString(4, CONFIRMPASSWORD );
            pst.setString(5, EMAIL );
            pst.setString(6, PHONENBR );
            pst.setString(7, ADDRESS );
       
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(null,"Your account is successfully created.");
            }
                
                    catch(SQLException exp)
                    {
                    Logger.getLogger(Register.class.getName()).log(Level.SEVERE,null,exp);
                    }  
            }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTextFieldfullnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldfullnameActionPerformed
        // TODO add your handling code here:
        
      
    }//GEN-LAST:event_jTextFieldfullnameActionPerformed

    private void jButtonclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonclearActionPerformed
        // TODO add your handling code here:
        
        jTextFieldfullname.setText(null);
        jTextFieldusername.setText(null);
        jPasswordFieldpassword.setText(null);
        jPasswordFieldcinfirmpassword.setText(null);
        jTextFieldemail.setText(null);
        jTextFieldphonenbr.setText(null);
        jTextFieldaddress.setText(null);
    }//GEN-LAST:event_jButtonclearActionPerformed

    private void jButtonbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonbackActionPerformed
      
    }//GEN-LAST:event_jButtonbackActionPerformed

    private void jTextFieldfullnameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldfullnameKeyReleased
       
        
    }//GEN-LAST:event_jTextFieldfullnameKeyReleased

    private void jTextFieldphonenbrKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldphonenbrKeyPressed
        // TODO add your handling code here:
        String PHONENBR=jTextFieldphonenbr.getText();
        int length=PHONENBR.length();
        char c = evt.getKeyChar();
        if(evt.getKeyChar()>='0'&&evt.getKeyChar()<='9')
        {
            if(length<10)
            {
                jTextFieldphonenbr.setEditable(true);
            }
            else{
                jTextFieldphonenbr.setEditable(false);
                
            }
        }else{
            if(evt.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE ||evt.getExtendedKeyCode()==KeyEvent.VK_DELETE)
            {
                jTextFieldphonenbr.setEditable(true); 
            }else{
                 jTextFieldphonenbr.setEditable(false);
            }
        }
        
    }//GEN-LAST:event_jTextFieldphonenbrKeyPressed

    private void jTextFieldfullnameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldfullnameKeyPressed
        // TODO add your handling code here:
        
       char c = evt.getKeyChar();
       if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c))
               {
                 jTextFieldfullname.setEditable(true);  
               }
       else{
           jTextFieldfullname.setEditable(false);
           
       }
    }//GEN-LAST:event_jTextFieldfullnameKeyPressed

    private void jTextFieldaddressKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldaddressKeyPressed
        // TODO add your handling code here:
        char c = evt.getKeyChar();
       if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c))
               {
                 jTextFieldaddress.setEditable(true);  
               }
       else{
                jTextFieldaddress.setEditable(false);
           
       }
    }//GEN-LAST:event_jTextFieldaddressKeyPressed

    private void jTextFieldemailKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldemailKeyReleased
     /*String PATTERN="^[a-zA-Z0-9][0,30][@][a-zA-Z0-9][0,10][.][a-zA-Z][0,5]$";
     Pattern patt=Pattern.compile(PATTERN);
     Matcher match=patt.matcher(jTextFieldemail.getText());
     if(!match.matches())
     {
       jTextFieldemail.setEditable(true); 
     } 
     else
     {
      jTextFieldemail.setEditable(false);    
     }*/
    }//GEN-LAST:event_jTextFieldemailKeyReleased

    public static void main(String args[]) {
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Register().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButtonback;
    private javax.swing.JButton jButtonclear;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabeladdress;
    private javax.swing.JLabel jLabelconfirmpassword;
    private javax.swing.JLabel jLabelemail;
    private javax.swing.JLabel jLabelfullname;
    private javax.swing.JLabel jLabelpassword;
    private javax.swing.JLabel jLabelphonenbr;
    private javax.swing.JLabel jLabelusername;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordFieldcinfirmpassword;
    private javax.swing.JPasswordField jPasswordFieldpassword;
    private javax.swing.JSlider jSlider1;
    private javax.swing.JTextField jTextFieldaddress;
    private javax.swing.JTextField jTextFieldemail;
    private javax.swing.JTextField jTextFieldfullname;
    private javax.swing.JTextField jTextFieldphonenbr;
    private javax.swing.JTextField jTextFieldusername;
    private javax.swing.JLabel logo;
    // End of variables declaration//GEN-END:variables
}
