package pharmacy;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
public class Customer extends javax.swing.JFrame {
    Connection conn;
    PreparedStatement pst;
    ResultSet rs;
    public Customer() {
        initComponents();
        imageicon();
        userlist();
    }
     public void imageicon()
    {
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/d.png"));
        Image img=i1.getImage();
        Image imageScale=img.getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);    
        ImageIcon scaledIcon=new ImageIcon(imageScale);
        logo.setIcon(scaledIcon);
        
    }
     public void userlist()
     {
         try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", "");
            Statement st = conn.createStatement();
            rs = st.executeQuery("select * from pharmacy.register");
            jTableuserlist.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException exp) {
            exp.printStackTrace();
        }
     }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        jLabelfullname = new javax.swing.JLabel();
        jLabelusername = new javax.swing.JLabel();
        jLabelpassword = new javax.swing.JLabel();
        jLabelconfirmpassword = new javax.swing.JLabel();
        jLabelemail = new javax.swing.JLabel();
        jLabelphonenbr = new javax.swing.JLabel();
        jLabeladdress = new javax.swing.JLabel();
        jTextFieldfullname = new javax.swing.JTextField();
        jTextFieldusername = new javax.swing.JTextField();
        jPasswordFieldpassword = new javax.swing.JPasswordField();
        jPasswordFieldcinfirmpassword = new javax.swing.JPasswordField();
        jTextFieldemail = new javax.swing.JTextField();
        jTextFieldphonenbr = new javax.swing.JTextField();
        jTextFieldaddress = new javax.swing.JTextField();
        jButtonadd = new javax.swing.JButton();
        jButtonupdate = new javax.swing.JButton();
        jButtondelete = new javax.swing.JButton();
        jButtonclear = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTableuserlist = new javax.swing.JTable();
        jLabeluserlist = new javax.swing.JLabel();
        jLabelusertype = new javax.swing.JLabel();
        jTextFieldusertype = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 0)));

        jLabelfullname.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelfullname.setForeground(new java.awt.Color(0, 102, 0));
        jLabelfullname.setText("FULL NAME:");

        jLabelusername.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelusername.setForeground(new java.awt.Color(0, 102, 0));
        jLabelusername.setText("USER NAME:");

        jLabelpassword.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelpassword.setForeground(new java.awt.Color(0, 102, 0));
        jLabelpassword.setText("PASSWORD:");

        jLabelconfirmpassword.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelconfirmpassword.setForeground(new java.awt.Color(0, 102, 0));
        jLabelconfirmpassword.setText("CONFIRM PASSWORD:");

        jLabelemail.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelemail.setForeground(new java.awt.Color(0, 102, 0));
        jLabelemail.setText("EMAIL:");

        jLabelphonenbr.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelphonenbr.setForeground(new java.awt.Color(0, 102, 0));
        jLabelphonenbr.setText("PHONE NBR:");

        jLabeladdress.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabeladdress.setForeground(new java.awt.Color(0, 102, 0));
        jLabeladdress.setText("ADDRESS:");

        jTextFieldfullname.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldfullname.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldfullname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldfullnameActionPerformed(evt);
            }
        });
        jTextFieldfullname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextFieldfullnameKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldfullnameKeyReleased(evt);
            }
        });

        jTextFieldusername.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldusername.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldusername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldusernameActionPerformed(evt);
            }
        });

        jPasswordFieldpassword.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jPasswordFieldpassword.setForeground(new java.awt.Color(0, 102, 0));

        jPasswordFieldcinfirmpassword.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jPasswordFieldcinfirmpassword.setForeground(new java.awt.Color(0, 102, 0));
        jPasswordFieldcinfirmpassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordFieldcinfirmpasswordActionPerformed(evt);
            }
        });

        jTextFieldemail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldemail.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldemailActionPerformed(evt);
            }
        });

        jTextFieldphonenbr.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldphonenbr.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldphonenbr.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextFieldphonenbrKeyPressed(evt);
            }
        });

        jTextFieldaddress.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldaddress.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldaddress.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextFieldaddressKeyPressed(evt);
            }
        });

        jButtonadd.setBackground(new java.awt.Color(0, 102, 0));
        jButtonadd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonadd.setForeground(new java.awt.Color(255, 255, 255));
        jButtonadd.setText("ADD");
        jButtonadd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonaddMouseClicked(evt);
            }
        });
        jButtonadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonaddActionPerformed(evt);
            }
        });

        jButtonupdate.setBackground(new java.awt.Color(0, 102, 0));
        jButtonupdate.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonupdate.setForeground(new java.awt.Color(255, 255, 255));
        jButtonupdate.setText("UPDATE");
        jButtonupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonupdateActionPerformed(evt);
            }
        });

        jButtondelete.setBackground(new java.awt.Color(0, 102, 0));
        jButtondelete.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtondelete.setForeground(new java.awt.Color(255, 255, 255));
        jButtondelete.setText("DELETE");
        jButtondelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtondeleteMouseClicked(evt);
            }
        });

        jButtonclear.setBackground(new java.awt.Color(0, 102, 0));
        jButtonclear.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonclear.setForeground(new java.awt.Color(255, 255, 255));
        jButtonclear.setText("CLEAR");
        jButtonclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonclearActionPerformed(evt);
            }
        });

        jTableuserlist.setForeground(new java.awt.Color(0, 102, 0));
        jTableuserlist.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "FULL NAME", "USER NAME", "PASSWORD", "CONFIRM PASSWORD", "EMAIL", "PHONE NBR", "ADDRESS", "USERTYPE"
            }
        ));
        jTableuserlist.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableuserlistMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTableuserlist);

        jLabeluserlist.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabeluserlist.setForeground(new java.awt.Color(0, 102, 0));
        jLabeluserlist.setText("CUSTOMER LIST");

        jLabelusertype.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelusertype.setForeground(new java.awt.Color(0, 102, 0));
        jLabelusertype.setText("USERTYPE:");

        jTextFieldusertype.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 0));
        jLabel1.setText("X");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 0));
        jLabel2.setText("Back");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 372, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(492, 492, 492)
                        .addComponent(jButtondelete, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)
                        .addComponent(jButtonclear)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(110, 110, 110)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelconfirmpassword)
                    .addComponent(jLabelpassword)
                    .addComponent(jLabelusername)
                    .addComponent(jLabelfullname))
                .addGap(1, 1, 1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextFieldfullname)
                    .addComponent(jTextFieldusername)
                    .addComponent(jPasswordFieldpassword)
                    .addComponent(jPasswordFieldcinfirmpassword))
                .addGap(48, 48, 48)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabelemail)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTextFieldemail, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabelphonenbr)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldphonenbr, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabeladdress)
                            .addComponent(jLabelusertype))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextFieldaddress)
                            .addComponent(jTextFieldusertype, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE))))
                .addGap(91, 91, 91))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 48, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 744, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jButtonadd, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButtonupdate, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabeluserlist))
                        .addGap(339, 339, 339))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)
                        .addGap(26, 26, 26)
                        .addComponent(jLabel2))
                    .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabelfullname)
                        .addComponent(jTextFieldfullname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabelemail))
                    .addComponent(jTextFieldemail, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jLabelusername))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextFieldusername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelphonenbr)
                            .addComponent(jTextFieldphonenbr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabelpassword))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jPasswordFieldpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabeladdress)
                            .addComponent(jTextFieldaddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelconfirmpassword)
                    .addComponent(jPasswordFieldcinfirmpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelusertype)
                    .addComponent(jTextFieldusertype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtondelete)
                    .addComponent(jButtonclear)
                    .addComponent(jButtonupdate)
                    .addComponent(jButtonadd, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addComponent(jLabeluserlist)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldfullnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldfullnameActionPerformed
     
    }//GEN-LAST:event_jTextFieldfullnameActionPerformed

    private void jTextFieldfullnameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldfullnameKeyPressed
        // TODO add your handling code here:

        char c = evt.getKeyChar();
        if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c))
        {
            jTextFieldfullname.setEditable(true);
        }
        else{
            jTextFieldfullname.setEditable(false);

        }
    }//GEN-LAST:event_jTextFieldfullnameKeyPressed

    private void jTextFieldfullnameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldfullnameKeyReleased
        // TODO add your handling code here:

    }//GEN-LAST:event_jTextFieldfullnameKeyReleased

    private void jTextFieldusernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldusernameActionPerformed

    }//GEN-LAST:event_jTextFieldusernameActionPerformed

    private void jPasswordFieldcinfirmpasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordFieldcinfirmpasswordActionPerformed

    }//GEN-LAST:event_jPasswordFieldcinfirmpasswordActionPerformed

    private void jTextFieldemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldemailActionPerformed

    }//GEN-LAST:event_jTextFieldemailActionPerformed

    private void jTextFieldphonenbrKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldphonenbrKeyPressed
        // TODO add your handling code here:
        String PHONENBR=jTextFieldphonenbr.getText();
        int length=PHONENBR.length();
        char c = evt.getKeyChar();
        if(evt.getKeyChar()>='0'&&evt.getKeyChar()<='9')
        {
            if(length<10)
            {
                jTextFieldphonenbr.setEditable(true);
            }
            else{
                jTextFieldphonenbr.setEditable(false);

            }
        }else{
            if(evt.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE ||evt.getExtendedKeyCode()==KeyEvent.VK_DELETE)
            {
                jTextFieldphonenbr.setEditable(true);
            }else{
                jTextFieldphonenbr.setEditable(false);
            }
        }

    }//GEN-LAST:event_jTextFieldphonenbrKeyPressed

    private void jTextFieldaddressKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldaddressKeyPressed
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c))
        {
            jTextFieldaddress.setEditable(true);
        }
        else{
            jTextFieldaddress.setEditable(false);

        }

    }//GEN-LAST:event_jTextFieldaddressKeyPressed

    private void jButtonaddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonaddMouseClicked

    }//GEN-LAST:event_jButtonaddMouseClicked

    private void jButtonaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonaddActionPerformed

            String FULLNAME =  jTextFieldfullname.getText();
            String USERNAME =jTextFieldusername.getText();
            String PASSWORD =String.valueOf(jPasswordFieldpassword.getText());
            String CONFIRMPASSWORD=String.valueOf(jPasswordFieldcinfirmpassword.getText());
            String EMAIL =jTextFieldemail.getText();
            String PHONENBR=jTextFieldphonenbr.getText();
            String ADDRESS = jTextFieldaddress.getText();
            
            if(FULLNAME.equals(""))
            {
               JOptionPane.showMessageDialog(null,"please enter your full name."); 
            
            }
            
            else if(USERNAME.equals(""))
            {
               JOptionPane.showMessageDialog(null,"please enter your user name."); 
            }
            
            else if(PASSWORD.equals(""))
            {
               JOptionPane.showMessageDialog(null,"please enter your password."); 
            }
            else if(!PASSWORD.equals(CONFIRMPASSWORD))
            {
               JOptionPane.showMessageDialog(null,"please retype your password again."); 
            }
            
            else if(EMAIL.equals(""))
            {
               JOptionPane.showMessageDialog(null,"please enter your email id."); 
            }
            
            else if(PHONENBR.equals(""))
            {
               JOptionPane.showMessageDialog(null,"please enter your phonenbr."); 
            }
            
            else if(ADDRESS.equals(""))
            {
               JOptionPane.showMessageDialog(null,"please enter your address."); 
            }
            else{
            
            PreparedStatement pst;
            String query = "INSERT INTO `register`(`FULLNAME`, `USERNMAE`, `PASSWORD`, `CONFIRMPASSWORD`, `EMAIL`, `PHONENBR`, `ADDRESS`) VALUES (?,?,?,?,?,?,?)";
            try{
            pst=Jdbc1connection.getConnection().prepareStatement(query);
            pst.setString(1, FULLNAME );
            pst.setString(2, USERNAME );
            pst.setString(3, PASSWORD );
            pst.setString(4, CONFIRMPASSWORD );
            pst.setString(5, EMAIL );
            pst.setString(6, PHONENBR );
            pst.setString(7, ADDRESS );
       
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(null,"Your account is successfully created.");
            }
                
                    catch(SQLException exp)
                    {
                     exp.printStackTrace();
                    }  
            }
    }//GEN-LAST:event_jButtonaddActionPerformed

    private void jButtonupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonupdateActionPerformed

        if (jTextFieldfullname.getText().isEmpty() || jTextFieldusername.getText().isEmpty() || jPasswordFieldpassword.getText().isEmpty() || jPasswordFieldcinfirmpassword.getText().isEmpty()||jTextFieldemail.getText().isEmpty()||jTextFieldphonenbr.getText().isEmpty()||jTextFieldaddress.getText().isEmpty()||jTextFieldphonenbr.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Missing information.");
        } else {
            try {

                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", "");
                String UpdateQuery = "Update pharmacy.register set FULLNAME='" + jTextFieldfullname.getText()+"'"+",USERNMAE='"+jTextFieldusername.getText()+"'"+",PASSWORD='"+jPasswordFieldpassword.getText()+"'"+",CONFIRMPASSWORD='"+jPasswordFieldcinfirmpassword.getText()+"'"+",EMAIL='"+jTextFieldemail.getText()+"'"+",ADDRESS='"+jTextFieldaddress.getText()+"'"+",USERTYPE='"+jTextFieldusertype.getText()+"'"+"where PHONENBR="+jTextFieldphonenbr.getText();
                Statement smt=conn.createStatement();
                smt.executeUpdate(UpdateQuery);
                JOptionPane.showMessageDialog(this, "Updated successfully.");
                userlist();
            } catch (SQLException exp) {
                exp.printStackTrace();
            }

        }
    }//GEN-LAST:event_jButtonupdateActionPerformed

    private void jButtondeleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtondeleteMouseClicked
        if (jTextFieldphonenbr.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter the phonenbr to be deleted.");
        } else {
            try {
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", "");
                String PHONENBR = jTextFieldphonenbr.getText();
                String Query = "Delete from pharmacy.register where PHONENBR=" + PHONENBR;
                Statement delete = conn.createStatement();
                delete.executeUpdate(Query);
                JOptionPane.showMessageDialog(this, "Deleted successfully");
                userlist();
                conn.close();
            } catch (SQLException exp) {
                exp.printStackTrace();
            }
        }
    }//GEN-LAST:event_jButtondeleteMouseClicked

    private void jButtonclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonclearActionPerformed
        // TODO add your handling code here:
        jTextFieldfullname.setText(null);
        jTextFieldusername.setText(null);
        jPasswordFieldpassword.setText(null);
        jPasswordFieldcinfirmpassword.setText(null);
        jTextFieldemail.setText(null);
        jTextFieldphonenbr.setText(null);
        jTextFieldaddress.setText(null);
        jTextFieldusertype.setText(null);

    }//GEN-LAST:event_jButtonclearActionPerformed

    private void jTableuserlistMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableuserlistMouseClicked
        DefaultTableModel model = (DefaultTableModel) jTableuserlist.getModel();
        int Myindex = jTableuserlist.getSelectedRow();
        jTextFieldfullname.setText(model.getValueAt(Myindex, 0).toString());
        jTextFieldusername.setText(model.getValueAt(Myindex, 1).toString());
        jPasswordFieldpassword.setText(model.getValueAt(Myindex, 2).toString());
        jPasswordFieldcinfirmpassword.setText(model.getValueAt(Myindex, 3).toString());
        jTextFieldemail.setText(model.getValueAt(Myindex, 4).toString());
        jTextFieldphonenbr.setText(model.getValueAt(Myindex, 5).toString());
        jTextFieldaddress.setText(model.getValueAt(Myindex, 6).toString());
        jTextFieldusertype.setText(model.getValueAt(Myindex, 7).toString());
        userlist();
        
    }//GEN-LAST:event_jTableuserlistMouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
     System.exit(0);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
     
        Adminhome obj=new Adminhome();
        obj.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel2MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Customer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonadd;
    private javax.swing.JButton jButtonclear;
    private javax.swing.JButton jButtondelete;
    private javax.swing.JButton jButtonupdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabeladdress;
    private javax.swing.JLabel jLabelconfirmpassword;
    private javax.swing.JLabel jLabelemail;
    private javax.swing.JLabel jLabelfullname;
    private javax.swing.JLabel jLabelpassword;
    private javax.swing.JLabel jLabelphonenbr;
    private javax.swing.JLabel jLabeluserlist;
    private javax.swing.JLabel jLabelusername;
    private javax.swing.JLabel jLabelusertype;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordFieldcinfirmpassword;
    private javax.swing.JPasswordField jPasswordFieldpassword;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTableuserlist;
    private javax.swing.JTextField jTextFieldaddress;
    private javax.swing.JTextField jTextFieldemail;
    private javax.swing.JTextField jTextFieldfullname;
    private javax.swing.JTextField jTextFieldphonenbr;
    private javax.swing.JTextField jTextFieldusername;
    private javax.swing.JTextField jTextFieldusertype;
    private javax.swing.JLabel logo;
    // End of variables declaration//GEN-END:variables
}
