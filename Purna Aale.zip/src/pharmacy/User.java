package pharmacy;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;
import java.util.Date;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import net.proteanit.sql.DbUtils;
public class User extends javax.swing.JFrame {
    Connection conn;
    PreparedStatement pst;
    ResultSet rs;
    public User() {
        initComponents();
        imageicon();
        date();
        medicinelist();
    }
    
   public void imageicon()
    {
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/d.png"));
        Image img=i1.getImage();
        Image imageScale=img.getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);    
        ImageIcon scaledIcon=new ImageIcon(imageScale);
        logo.setIcon(scaledIcon);
        
    }
   public void date()
   {
       Date d1=new Date();
       SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd");
       date.setText(s.format(d1));
       
   }
   public void medicinelist() {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", "");
            Statement st = conn.createStatement();
            rs = st.executeQuery("select * from pharmacy.admin");
            jTablemedicinelist.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException exp) {
            exp.printStackTrace();
        }

    }
   
    private void update()
   {
       int newqty = oldqty-Integer.valueOf(jTextFieldquantity.getText());
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", ""); 
            String UpdateQuery = "Update pharmacy.admin set QUANTITY='"+newqty+"'"+"where MEDID="+productid;
            Statement smt=conn.createStatement();
            smt.executeUpdate(UpdateQuery);
             medicinelist();
         } catch (SQLException exp) {
            exp.printStackTrace();
         }
             }
    public void customer()
    {
        try{
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", ""); 
           Statement st = conn.createStatement();
           String Query="select * from pharmacy.register";
           rs = st.executeQuery(Query);
           while(rs.next())
           {
               String name=rs.getString("USERNAME");
               jTextField1.setText(name);
               String phone=rs.getString("PHONENBR");
               jTextField2.setText(phone);
               
           }
        }
        catch(SQLException exp)
        {
           exp.printStackTrace();  
        }
    }
       @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelquantity = new javax.swing.JLabel();
        jTextFieldquantity = new javax.swing.JTextField();
        jLabelbill = new javax.swing.JLabel();
        jLabelmedcinelist = new javax.swing.JLabel();
        jButtondelete = new javax.swing.JButton();
        jButtonclear = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTablemedicinelist = new javax.swing.JTable();
        jLabeldate = new javax.swing.JLabel();
        date = new javax.swing.JLabel();
        logo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabeltotprice = new javax.swing.JLabel();
        jTextFieldprice = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablebill = new javax.swing.JTable();
        jButtonupdate = new javax.swing.JButton();
        jButtonconformorder = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButtonaddtobill = new javax.swing.JButton();
        jTextFieldtotprice = new javax.swing.JTextField();
        jLabelprice1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 0)));

        jLabelquantity.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelquantity.setForeground(new java.awt.Color(0, 102, 0));
        jLabelquantity.setText("QUANTITY:");

        jTextFieldquantity.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldquantity.setForeground(new java.awt.Color(0, 102, 0));

        jLabelbill.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabelbill.setForeground(new java.awt.Color(0, 102, 0));
        jLabelbill.setText("BILL");

        jLabelmedcinelist.setBackground(new java.awt.Color(255, 255, 255));
        jLabelmedcinelist.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabelmedcinelist.setForeground(new java.awt.Color(0, 102, 0));
        jLabelmedcinelist.setText("MEDCINE LIST");

        jButtondelete.setBackground(new java.awt.Color(0, 102, 0));
        jButtondelete.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtondelete.setForeground(new java.awt.Color(255, 255, 255));
        jButtondelete.setText("Delete");
        jButtondelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtondeleteMouseClicked(evt);
            }
        });

        jButtonclear.setBackground(new java.awt.Color(0, 102, 0));
        jButtonclear.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonclear.setForeground(new java.awt.Color(255, 255, 255));
        jButtonclear.setText("Clear");
        jButtonclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonclearActionPerformed(evt);
            }
        });

        jTablemedicinelist.setForeground(new java.awt.Color(0, 102, 0));
        jTablemedicinelist.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "MED ID", "MED NAME", "MED CATAGORY", "MED PRICE", "QUANTITY", "MAN DATE", "EXPIRE DATE", "COMPANY"
            }
        ));
        jTablemedicinelist.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablemedicinelistMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTablemedicinelist);

        jLabeldate.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabeldate.setForeground(new java.awt.Color(0, 102, 0));
        jLabeldate.setText("Date:");

        date.setForeground(new java.awt.Color(0, 102, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 0));
        jLabel1.setText("X");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabeltotprice.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabeltotprice.setForeground(new java.awt.Color(0, 102, 0));
        jLabeltotprice.setText("TOTAL:");

        jTextFieldprice.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldprice.setForeground(new java.awt.Color(0, 102, 0));

        jTablebill.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "BILL ID", "MED NAME", "MEDTPYE", "QUANTITY ", "QUANTITY PRICE", "TOTAL PRICE"
            }
        ));
        jTablebill.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablebillMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablebill);

        jButtonupdate.setBackground(new java.awt.Color(0, 102, 0));
        jButtonupdate.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonupdate.setForeground(new java.awt.Color(255, 255, 255));
        jButtonupdate.setText("Update");
        jButtonupdate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonupdateMouseClicked(evt);
            }
        });
        jButtonupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonupdateActionPerformed(evt);
            }
        });

        jButtonconformorder.setBackground(new java.awt.Color(0, 102, 0));
        jButtonconformorder.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonconformorder.setForeground(new java.awt.Color(255, 255, 255));
        jButtonconformorder.setText("Conform Order");
        jButtonconformorder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonconformorderActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 0));
        jLabel2.setText("Back");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jButtonaddtobill.setBackground(new java.awt.Color(0, 102, 0));
        jButtonaddtobill.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonaddtobill.setForeground(new java.awt.Color(255, 255, 255));
        jButtonaddtobill.setText("Add To Bill");
        jButtonaddtobill.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonaddtobillMouseClicked(evt);
            }
        });
        jButtonaddtobill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonaddtobillActionPerformed(evt);
            }
        });

        jTextFieldtotprice.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldtotprice.setForeground(new java.awt.Color(0, 102, 0));

        jLabelprice1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelprice1.setForeground(new java.awt.Color(0, 102, 0));
        jLabelprice1.setText("PRICE:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 0));
        jLabel3.setText("Customer Name:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 102, 0));
        jLabel4.setText("Phone nbr:");

        jTextField1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(0, 102, 0));

        jTextField2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextField2.setForeground(new java.awt.Color(0, 102, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabelbill)
                        .addGap(74, 74, 74)
                        .addComponent(jLabeldate)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(72, 72, 72))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabelmedcinelist)
                        .addGap(377, 377, 377))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jButtonaddtobill, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(11, 11, 11))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelquantity)
                                    .addComponent(jLabelprice1))
                                .addGap(69, 69, 69)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jTextFieldprice, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextFieldquantity, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(55, 55, 55))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButtonupdate, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButtondelete, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jButtonclear)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabeltotprice)
                                .addGap(18, 18, 18)
                                .addComponent(jTextFieldtotprice, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButtonconformorder))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 807, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(41, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(148, 148, 148)
                                .addComponent(jLabel4)
                                .addGap(54, 54, 54))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField1)
                            .addComponent(jTextField2, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)
                        .addGap(14, 14, 14)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(jLabel2))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)))
                    .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(108, 108, 108)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextFieldquantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelquantity))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextFieldprice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelprice1)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabelbill)
                                .addComponent(jLabeldate))
                            .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonclear)
                    .addComponent(jButtondelete)
                    .addComponent(jButtonupdate)
                    .addComponent(jButtonconformorder)
                    .addComponent(jButtonaddtobill)
                    .addComponent(jTextFieldtotprice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabeltotprice))
                .addGap(28, 28, 28)
                .addComponent(jLabelmedcinelist)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonaddtobillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonaddtobillActionPerformed
      
    }//GEN-LAST:event_jButtonaddtobillActionPerformed
      
    int i=1,qtyprice,totalprice=0,total;
    String medname,medtype;  
    private void jButtonaddtobillMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonaddtobillMouseClicked
        if(flag==0||jTextFieldquantity.getText().isEmpty()||jTextFieldprice.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(this,"please fil the required filed");
        }
            else{
            totalprice = Integer.valueOf(jTextFieldprice.getText())*Integer.valueOf(jTextFieldquantity.getText());
            Vector v1=new Vector();
            v1.add(i);
            v1.add(medname);
            v1.add(medtype);
            v1.add(jTextFieldquantity.getText());
            v1.add(jTextFieldprice.getText());
            v1.add(totalprice); 
            /*java.lang.String highsensective = null;
            //if(medtype == highsensective)
            {
              Highdosemedcineaprove obj=new Highdosemedcineaprove();
              obj.setVisible(true);
              dispose();
            }else*/
            DefaultTableModel model1 = (DefaultTableModel) jTablebill.getModel();
            model1.addRow(v1);
            
            total=total+totalprice;
            jTextFieldtotprice.setText("Rs"+total);
            update();
             i++;
            JOptionPane.showMessageDialog(this,"added to bill successfully");
        }
    }//GEN-LAST:event_jButtonaddtobillMouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        Userhome obj=new Userhome();
        obj.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jButtonupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonupdateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButtonupdateActionPerformed

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel1MouseClicked
    int flag = 0,productid,oldqty;
    private void jTablemedicinelistMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablemedicinelistMouseClicked
        DefaultTableModel model = (DefaultTableModel) jTablemedicinelist.getModel();
        int Myindex = jTablemedicinelist.getSelectedRow();
        productid=Integer.valueOf(model.getValueAt(Myindex, 0).toString());
        //jTextFieldmedicineid.setText(model.getValueAt(Myindex, 0).toString());
        medname=model.getValueAt(Myindex, 1).toString();
        medtype=model.getValueAt(Myindex, 2).toString();
        oldqty=Integer.valueOf(model.getValueAt(Myindex, 4).toString());
        jTextFieldprice.setText(model.getValueAt(Myindex, 3).toString());
        flag = 1;
        medicinelist();
    }//GEN-LAST:event_jTablemedicinelistMouseClicked

    private void jButtonclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonclearActionPerformed
        jTextFieldprice.setText(null);
        jTextFieldquantity.setText(null);

    }//GEN-LAST:event_jButtonclearActionPerformed

    private void jButtonupdateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonupdateMouseClicked
      DefaultTableModel model1 = (DefaultTableModel) jTablebill.getModel();  
      if(jTablebill.getSelectedRowCount() == 1)
      {
          String qty=jTextFieldquantity.getText();
          String pric=jTextFieldprice.getText();
          model1.setValueAt(qty,jTablebill.getSelectedRow(), 2);
          model1.setValueAt(pric,jTablebill.getSelectedRow(),3);
          JOptionPane.showMessageDialog(this,"updated successfully....");
      }else{
          if(jTablebill.getSelectedRowCount() == 0)
          {
            JOptionPane.showMessageDialog(this,"table is empty....");
 
          
          }else{
                JOptionPane.showMessageDialog(this,"please select the single row to update....");    
               }
      }
    }//GEN-LAST:event_jButtonupdateMouseClicked

    private void jTablebillMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablebillMouseClicked
        DefaultTableModel model = (DefaultTableModel) jTablebill.getModel();
        int Myindex = jTablebill.getSelectedRow();
        jTextFieldquantity.setText(model.getValueAt(Myindex, 2).toString());
        jTextFieldprice.setText(model.getValueAt(Myindex, 3).toString());
    }//GEN-LAST:event_jTablebillMouseClicked

    private void jButtondeleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtondeleteMouseClicked
     DefaultTableModel model2 = (DefaultTableModel) jTablebill.getModel();  
      if(jTablebill.getSelectedRowCount() == 1)
      {
          model2.removeRow(jTablebill.getSelectedRow());
          JOptionPane.showMessageDialog(this,"deleted  successfully....");
      }else{
          if(jTablebill.getSelectedRowCount() == 0)
          {
            JOptionPane.showMessageDialog(this,"table is empty....");
 
          
          }else{
                JOptionPane.showMessageDialog(this,"please select the single row to update....");    
               }
      }  
    }//GEN-LAST:event_jButtondeleteMouseClicked

    private void jButtonconformorderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonconformorderActionPerformed
        DefaultTableModel model2 = (DefaultTableModel) jTablebill.getModel();  
      if(jTablebill.getRowCount() == 0)
      {
          JOptionPane.showMessageDialog(this,"table is empty....");
      }else{
         String BILLID,MEDNAME,QUANTITY,PRICE,TOTALPRICE;
         try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy","root","");
            for(int i=0;i<model2.getRowCount();i++)
            {
             BILLID = model2.getValueAt(i, 0).toString();
             MEDNAME = model2.getValueAt(i, 1).toString();
             QUANTITY= model2.getValueAt(i, 2).toString();
             PRICE= model2.getValueAt(i, 3).toString();
             TOTALPRICE= model2.getValueAt(i, 4).toString();
             String query = "INSERT INTO `customerorder`(`BILLID`, `MEDNAME`, `QUANTITY`, `PRICE`, `TOTALPRICE`) VALUES (?, ?, ?,?,?)";
             PreparedStatement pst=conn.prepareStatement(query);
             pst.setString(1, BILLID);
             pst.setString(2, MEDNAME);
             pst.setString(3, QUANTITY);
             pst.setString(4, PRICE);
             pst.setString(5, TOTALPRICE);
             pst.execute();
            }
            JOptionPane.showMessageDialog(this,"successfully order");
            model2.setRowCount(0);
         }

        catch(Exception exp)
        {
            JOptionPane.showMessageDialog(null,exp);
        }
        
      }  
    }//GEN-LAST:event_jButtonconformorderActionPerformed
            public static void main(String args[]) {
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new User().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel date;
    private javax.swing.JButton jButtonaddtobill;
    private javax.swing.JButton jButtonclear;
    private javax.swing.JButton jButtonconformorder;
    private javax.swing.JButton jButtondelete;
    private javax.swing.JButton jButtonupdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabelbill;
    private javax.swing.JLabel jLabeldate;
    private javax.swing.JLabel jLabelmedcinelist;
    private javax.swing.JLabel jLabelprice1;
    private javax.swing.JLabel jLabelquantity;
    private javax.swing.JLabel jLabeltotprice;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTablebill;
    private javax.swing.JTable jTablemedicinelist;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextFieldprice;
    private javax.swing.JTextField jTextFieldquantity;
    private javax.swing.JTextField jTextFieldtotprice;
    private javax.swing.JLabel logo;
    // End of variables declaration//GEN-END:variables

    private int setText(String toString) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    private void String() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
