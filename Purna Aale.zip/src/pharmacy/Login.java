package pharmacy;
import java.awt.Cursor;
import java.awt.Image;
import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.ImageIcon;
public class Login extends javax.swing.JFrame {
    Connection conn=null;
    
    public Login() {
        initComponents();
        imageicon();
        
    }
    public void imageicon()
    {
        ImageIcon i=new ImageIcon(ClassLoader.getSystemResource("icon/d.png"));
        Image img=i.getImage();
        Image imageScale=img.getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);    
        ImageIcon scaledIcon=new ImageIcon(imageScale);
        logo.setIcon(scaledIcon);
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabeluertypeselect = new javax.swing.JLabel();
        jComboBoxuserselection = new javax.swing.JComboBox<>();
        jLabelusername = new javax.swing.JLabel();
        jLabelpassword = new javax.swing.JLabel();
        jButtonsignin = new javax.swing.JButton();
        jButtonforgotpassword = new javax.swing.JButton();
        jLabeldonthaveacccount = new javax.swing.JLabel();
        jTextFieldusername = new javax.swing.JTextField();
        jPasswordFieldpassword = new javax.swing.JPasswordField();
        jButtonclear = new javax.swing.JButton();
        logo = new javax.swing.JLabel();
        jLabelexit = new javax.swing.JLabel();
        jButtonclear1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 0)));
        jPanel3.setForeground(new java.awt.Color(51, 153, 0));

        jLabeluertypeselect.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabeluertypeselect.setForeground(new java.awt.Color(0, 102, 0));
        jLabeluertypeselect.setText("SELECT USER TYPE :");

        jComboBoxuserselection.setBackground(new java.awt.Color(0, 102, 0));
        jComboBoxuserselection.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jComboBoxuserselection.setForeground(new java.awt.Color(255, 255, 255));
        jComboBoxuserselection.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ADMIN", "USER" }));

        jLabelusername.setBackground(new java.awt.Color(153, 0, 0));
        jLabelusername.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelusername.setForeground(new java.awt.Color(0, 102, 0));
        jLabelusername.setText("USERNAME:");

        jLabelpassword.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelpassword.setForeground(new java.awt.Color(0, 102, 0));
        jLabelpassword.setText("PASSWORD:");

        jButtonsignin.setBackground(new java.awt.Color(0, 102, 0));
        jButtonsignin.setForeground(new java.awt.Color(255, 255, 255));
        jButtonsignin.setText("SIGNIN");
        jButtonsignin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonsigninActionPerformed(evt);
            }
        });

        jButtonforgotpassword.setBackground(new java.awt.Color(0, 102, 0));
        jButtonforgotpassword.setForeground(new java.awt.Color(255, 255, 255));
        jButtonforgotpassword.setText("FORGOT PASSWORD");
        jButtonforgotpassword.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButtonforgotpasswordMouseMoved(evt);
            }
        });
        jButtonforgotpassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonforgotpasswordMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonforgotpasswordMousePressed(evt);
            }
        });

        jLabeldonthaveacccount.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabeldonthaveacccount.setForeground(new java.awt.Color(0, 102, 0));
        jLabeldonthaveacccount.setText("IF YOU DON'T HAVE ACCCOUNT ???");

        jTextFieldusername.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldusername.setForeground(new java.awt.Color(0, 102, 0));

        jPasswordFieldpassword.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jPasswordFieldpassword.setForeground(new java.awt.Color(0, 102, 0));

        jButtonclear.setBackground(new java.awt.Color(0, 102, 0));
        jButtonclear.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButtonclear.setForeground(new java.awt.Color(255, 255, 255));
        jButtonclear.setText("Register");
        jButtonclear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonclearMouseClicked(evt);
            }
        });
        jButtonclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonclearActionPerformed(evt);
            }
        });

        jLabelexit.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabelexit.setForeground(new java.awt.Color(0, 102, 0));
        jLabelexit.setText("X");
        jLabelexit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelexitMouseClicked(evt);
            }
        });

        jButtonclear1.setBackground(new java.awt.Color(0, 102, 0));
        jButtonclear1.setForeground(new java.awt.Color(255, 255, 255));
        jButtonclear1.setText("CLEAR");
        jButtonclear1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonclear1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabeluertypeselect)
                                    .addComponent(jLabelusername))
                                .addGap(26, 26, 26)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextFieldusername, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBoxuserselection, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabeldonthaveacccount, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jButtonclear)
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addComponent(jLabelpassword)
                                    .addGap(72, 72, 72)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jButtonforgotpassword, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                            .addComponent(jButtonsignin)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                                            .addComponent(jButtonclear1))
                                        .addComponent(jPasswordFieldpassword)))))
                        .addContainerGap(83, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabelexit)
                        .addContainerGap())))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabelexit))
                .addGap(39, 39, 39)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabeluertypeselect)
                    .addComponent(jComboBoxuserselection, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelusername)
                            .addComponent(jTextFieldusername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(jLabelpassword))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jPasswordFieldpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                        .addComponent(jButtonclear1)
                        .addGap(13, 13, 13))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonsignin)
                        .addGap(21, 21, 21)))
                .addComponent(jButtonforgotpassword)
                .addGap(18, 18, 18)
                .addComponent(jLabeldonthaveacccount)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButtonclear)
                .addGap(33, 33, 33))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonforgotpasswordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonforgotpasswordMouseClicked

    }//GEN-LAST:event_jButtonforgotpasswordMouseClicked

    
    private void jButtonsigninActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonsigninActionPerformed
       PreparedStatement pst;
       ResultSet rs;
       String USERNAME =jTextFieldusername.getText();
       String PASSWORD =String.valueOf(jPasswordFieldpassword.getText());
       String USERTYPE=jComboBoxuserselection.getSelectedItem().toString();
       String query = "SELECT * FROM `register` WHERE `USERNMAE`=? AND `PASSWORD`=? AND `USERTYPE`=?";
        
        try{
                    pst=Jdbc1connection.getConnection().prepareStatement(query);
                    pst.setString(1, USERNAME );
                    pst.setString(2, PASSWORD );
                    pst.setString(3, USERTYPE);
                    rs=pst.executeQuery();
                   
                    if(rs.next())
                    {
                        JOptionPane.showMessageDialog(this,"you are successfully login" );
                        if(jComboBoxuserselection.getSelectedIndex()==0)
                        {
                            Adminhome obj=new Adminhome();
                            obj.setVisible(true);
                            dispose();
                       }
                        else{
                            Userhome obj=new Userhome();
                            obj.setVisible(true);
                            dispose();
                        }
                            
                        }
                        else{
                                
                                
                        JOptionPane.showMessageDialog(this,"Incorrect username and password");
                    }
                    
                    }
                    catch(SQLException exp)
                    {
                    JOptionPane.showMessageDialog(this,exp);
                    }
                                     
    }//GEN-LAST:event_jButtonsigninActionPerformed

    private void jButtonclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonclearActionPerformed
        jTextFieldusername.setText(null);   
        jPasswordFieldpassword.setText(null);
  
    }//GEN-LAST:event_jButtonclearActionPerformed

    private void jLabelexitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelexitMouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabelexitMouseClicked

    private void jButtonclear1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonclear1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButtonclear1ActionPerformed

    private void jButtonclearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonclearMouseClicked
     Register obj=new Register();
     obj.setVisible(true);
     dispose();
    }//GEN-LAST:event_jButtonclearMouseClicked

    private void jButtonforgotpasswordMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonforgotpasswordMouseMoved
      jButtonforgotpassword.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_jButtonforgotpasswordMouseMoved

    private void jButtonforgotpasswordMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonforgotpasswordMousePressed
      Forgotpassword obj=new Forgotpassword();
        obj.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButtonforgotpasswordMousePressed

    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonclear;
    private javax.swing.JButton jButtonclear1;
    private javax.swing.JButton jButtonforgotpassword;
    private javax.swing.JButton jButtonsignin;
    private javax.swing.JComboBox<String> jComboBoxuserselection;
    private javax.swing.JLabel jLabeldonthaveacccount;
    private javax.swing.JLabel jLabelexit;
    private javax.swing.JLabel jLabelpassword;
    private javax.swing.JLabel jLabeluertypeselect;
    private javax.swing.JLabel jLabelusername;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPasswordField jPasswordFieldpassword;
    private javax.swing.JTextField jTextFieldusername;
    private javax.swing.JLabel logo;
    // End of variables declaration//GEN-END:variables
}
