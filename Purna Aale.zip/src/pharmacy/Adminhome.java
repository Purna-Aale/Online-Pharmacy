
package pharmacy;
import java.awt.Image;
import javax.swing.ImageIcon;

public class Adminhome extends javax.swing.JFrame {

    public Adminhome() {
        initComponents();
        imageicon();
        imageicon1();
        imageicon2();
        imageicon3();
        imageicon4();
        imageicon5();
        imageicon6();
        imageicon7();
    }
     public void imageicon() {
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/d.png"));
        Image img = i1.getImage();
        Image imageScale = img.getScaledInstance(companylogo.getWidth(), companylogo.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imageScale);
        companylogo.setIcon(scaledIcon);
    }
     public void imageicon1() {
        ImageIcon i2 = new ImageIcon(ClassLoader.getSystemResource("icon/e.png"));
        Image img = i2.getImage();
        Image imageScale = img.getScaledInstance(product.getWidth(), product.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imageScale);
        product.setIcon(scaledIcon);
    }
     public void imageicon2() {
        ImageIcon i3 = new ImageIcon(ClassLoader.getSystemResource("icon/a.png"));
        Image img = i3.getImage();
        Image imageScale = img.getScaledInstance(customer.getWidth(), customer.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imageScale);
        customer.setIcon(scaledIcon);
    }
     public void imageicon3() {
        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icon/f.png"));
        Image img = i4.getImage();
        Image imageScale = img.getScaledInstance(productcatagory.getWidth(), productcatagory.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imageScale);
        productcatagory.setIcon(scaledIcon);
    }
     public void imageicon4() {
        ImageIcon i3 = new ImageIcon(ClassLoader.getSystemResource("icon/c3.png"));
        Image img = i3.getImage();
        Image imageScale = img.getScaledInstance(customerorder.getWidth(), customerorder.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imageScale);
        customerorder.setIcon(scaledIcon);
    }
     public void imageicon5() {
        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icon/c.png"));
        Image img = i4.getImage();
        Image imageScale = img.getScaledInstance(report.getWidth(), report.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imageScale);
        report.setIcon(scaledIcon);
    }
      public void imageicon6() {
        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icon/c.png"));
        Image img = i4.getImage();
        Image imageScale = img.getScaledInstance(report.getWidth(), report.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imageScale);
        report.setIcon(scaledIcon);
    }
      public void imageicon7() {
        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icon/g.png"));
        Image img = i4.getImage();
        Image imageScale = img.getScaledInstance(jLabelcompany.getWidth(), jLabelcompany.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imageScale);
        jLabelcompany.setIcon(scaledIcon);
    }
     

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jYearChooser1 = new com.toedter.calendar.JYearChooser();
        jPanel1 = new javax.swing.JPanel();
        companylogo = new javax.swing.JLabel();
        customerorder = new javax.swing.JLabel();
        product = new javax.swing.JLabel();
        report = new javax.swing.JLabel();
        customer = new javax.swing.JLabel();
        productcatagory = new javax.swing.JLabel();
        jLabelproduct = new javax.swing.JLabel();
        jLabelcustomerorder = new javax.swing.JLabel();
        jLabelreport = new javax.swing.JLabel();
        jLabelcustomer = new javax.swing.JLabel();
        jLabelcatagory = new javax.swing.JLabel();
        jLabelcompany = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        exit = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 0)));

        customerorder.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                customerorderMouseClicked(evt);
            }
        });

        product.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                productMouseClicked(evt);
            }
        });

        customer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                customerMouseClicked(evt);
            }
        });

        productcatagory.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                productcatagoryMouseClicked(evt);
            }
        });

        jLabelproduct.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelproduct.setForeground(new java.awt.Color(0, 102, 0));
        jLabelproduct.setText("Product");

        jLabelcustomerorder.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelcustomerorder.setForeground(new java.awt.Color(0, 102, 0));
        jLabelcustomerorder.setText("Customer order");

        jLabelreport.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelreport.setForeground(new java.awt.Color(0, 102, 0));
        jLabelreport.setText("Report");

        jLabelcustomer.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelcustomer.setForeground(new java.awt.Color(0, 102, 0));
        jLabelcustomer.setText("Customer");

        jLabelcatagory.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelcatagory.setForeground(new java.awt.Color(0, 102, 0));
        jLabelcatagory.setText("Catagory");

        jLabelcompany.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelcompanyMouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 0));
        jLabel2.setText("Company");

        exit.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        exit.setForeground(new java.awt.Color(0, 102, 0));
        exit.setText("X");
        exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitMouseClicked(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(0, 102, 0));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("LOG OUT");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(companylogo, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(111, 111, 111)
                .addComponent(exit)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(customerorder, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(product, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(customer, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(94, 94, 94)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabelcompany, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(productcatagory, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(122, 122, 122)
                                .addComponent(jLabelproduct)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabelcatagory)
                                .addGap(54, 54, 54)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(82, 82, 82)
                                .addComponent(jLabelcustomerorder)
                                .addGap(9, 9, 9))
                            .addComponent(report, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(109, 109, 109))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(118, 118, 118)
                .addComponent(jLabelcustomer)
                .addGap(164, 164, 164)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelreport)
                .addGap(146, 146, 146))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(338, 338, 338)
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(exit)
                    .addComponent(companylogo, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(177, 177, 177)
                        .addComponent(customer, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabelcustomer))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(product, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelproduct))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(customerorder, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabelcustomerorder))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(productcatagory, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabelcatagory)))
                                .addGap(49, 49, 49)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(report, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabelcompany, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabelreport))))
                .addGap(33, 33, 33)
                .addComponent(jButton1)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void productMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_productMouseClicked
       Product obj=new Product();
       obj.setVisible(true);
       dispose();
    }//GEN-LAST:event_productMouseClicked

    private void jLabelcompanyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelcompanyMouseClicked
        Company obj=new Company();
        obj.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelcompanyMouseClicked

    private void exitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitMouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
      System.exit(0);  
    }//GEN-LAST:event_jButton1MouseClicked

    private void customerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_customerMouseClicked
        Customer obj=new Customer();
        obj.setVisible(true);
        dispose();
    }//GEN-LAST:event_customerMouseClicked

    private void productcatagoryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_productcatagoryMouseClicked
        Catagory obj=new Catagory();
        obj.setVisible(true);
        dispose();
    }//GEN-LAST:event_productcatagoryMouseClicked

    private void customerorderMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_customerorderMouseClicked
    Customerorderviewbyadmin obj=new Customerorderviewbyadmin ();
    obj.setVisible(true);
    dispose();
    }//GEN-LAST:event_customerorderMouseClicked

    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Adminhome().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel companylogo;
    private javax.swing.JLabel customer;
    private javax.swing.JLabel customerorder;
    private javax.swing.JLabel exit;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabelcatagory;
    private javax.swing.JLabel jLabelcompany;
    private javax.swing.JLabel jLabelcustomer;
    private javax.swing.JLabel jLabelcustomerorder;
    private javax.swing.JLabel jLabelproduct;
    private javax.swing.JLabel jLabelreport;
    private javax.swing.JPanel jPanel1;
    private com.toedter.calendar.JYearChooser jYearChooser1;
    private javax.swing.JLabel product;
    private javax.swing.JLabel productcatagory;
    private javax.swing.JLabel report;
    // End of variables declaration//GEN-END:variables
}
