package pharmacy;
import java.awt.Image;
import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class Product extends javax.swing.JFrame {
    Connection conn;
    PreparedStatement pst;
    ResultSet rs;

    public Product() {
        initComponents();
        medicinelist();
        company(); 
        imageicon();
        catagory();
    }
    public void imageicon()
    {
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/d.png"));
        Image img=i1.getImage();
        Image imageScale=img.getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);    
        ImageIcon scaledIcon=new ImageIcon(imageScale);
        logo.setIcon(scaledIcon);
        
    }

    public void medicinelist() {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", "");
            Statement st = conn.createStatement();
            rs = st.executeQuery("select * from pharmacy.admin");
            jTablemedicinelist.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException exp) {
            exp.printStackTrace();
        }

    }
    public void company()
    {
        try{
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", ""); 
           Statement st = conn.createStatement();
           String Query="select * from pharmacy.companymanage";
           rs = st.executeQuery(Query);
           while(rs.next())
           {
               String mycompany=rs.getString("COMNAME");
               company.addItem(mycompany);
               
           }
        }
        catch(SQLException exp)
        {
           exp.printStackTrace();  
        }
    }
    public void catagory()
    {
        try{
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", ""); 
           Statement st = conn.createStatement();
           String Query="select * from pharmacy.catagory";
           rs = st.executeQuery(Query);
           while(rs.next())
           {
               String mycatagory=rs.getString("CATNAME");
               jComboBoxmedcinecatagory.addItem(mycatagory);
               
           }
        }
        catch(SQLException exp)
        {
           exp.printStackTrace();  
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabelmedicineid = new javax.swing.JLabel();
        jLabelmedicinename = new javax.swing.JLabel();
        jLabelmedicineprice = new javax.swing.JLabel();
        jLabelquantity = new javax.swing.JLabel();
        jLabelmanufacturedate = new javax.swing.JLabel();
        jLabelexpiredate = new javax.swing.JLabel();
        jLabelcompany = new javax.swing.JLabel();
        jTextFieldmedicineid = new javax.swing.JTextField();
        jTextFieldmedicinenmae = new javax.swing.JTextField();
        jTextFieldmedicineprice = new javax.swing.JTextField();
        jTextFieldquantity = new javax.swing.JTextField();
        jDateChoosermanufacturedate = new com.toedter.calendar.JDateChooser();
        jDateChooserexpiredate = new com.toedter.calendar.JDateChooser();
        company = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabelmedicinelist = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTablemedicinelist = new javax.swing.JTable();
        jLabelmedicinecatagory = new javax.swing.JLabel();
        jComboBoxmedcinecatagory = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jButtonclear = new javax.swing.JButton();
        jButtonupdate = new javax.swing.JButton();
        jButtonadd = new javax.swing.JButton();
        jButtondelete = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        logo = new javax.swing.JLabel();

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelmedicineid.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelmedicineid.setForeground(new java.awt.Color(0, 102, 0));
        jLabelmedicineid.setText("MEDICINE ID:");
        getContentPane().add(jLabelmedicineid, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 160, -1, -1));

        jLabelmedicinename.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelmedicinename.setForeground(new java.awt.Color(0, 102, 0));
        jLabelmedicinename.setText("MEDICINE NAME:");
        getContentPane().add(jLabelmedicinename, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 200, -1, -1));

        jLabelmedicineprice.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelmedicineprice.setForeground(new java.awt.Color(0, 102, 0));
        jLabelmedicineprice.setText("MEDICINE PRICE:");
        getContentPane().add(jLabelmedicineprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 290, -1, 22));

        jLabelquantity.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelquantity.setForeground(new java.awt.Color(0, 102, 0));
        jLabelquantity.setText("QUANTITY:");
        getContentPane().add(jLabelquantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 160, -1, -1));

        jLabelmanufacturedate.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelmanufacturedate.setForeground(new java.awt.Color(0, 102, 0));
        jLabelmanufacturedate.setText("MANFACTURE DATE:");
        getContentPane().add(jLabelmanufacturedate, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 200, -1, -1));

        jLabelexpiredate.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelexpiredate.setForeground(new java.awt.Color(0, 102, 0));
        jLabelexpiredate.setText("EXPIRE DATE:");
        getContentPane().add(jLabelexpiredate, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 240, -1, -1));

        jLabelcompany.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelcompany.setForeground(new java.awt.Color(0, 102, 0));
        jLabelcompany.setText("COMPANY:");
        getContentPane().add(jLabelcompany, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 290, -1, -1));

        jTextFieldmedicineid.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldmedicineid.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldmedicineid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldmedicineidActionPerformed(evt);
            }
        });
        getContentPane().add(jTextFieldmedicineid, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 160, 106, -1));

        jTextFieldmedicinenmae.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldmedicinenmae.setForeground(new java.awt.Color(0, 102, 0));
        getContentPane().add(jTextFieldmedicinenmae, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 200, 108, -1));

        jTextFieldmedicineprice.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldmedicineprice.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldmedicineprice.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldmedicinepriceKeyTyped(evt);
            }
        });
        getContentPane().add(jTextFieldmedicineprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 290, 108, -1));

        jTextFieldquantity.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextFieldquantity.setForeground(new java.awt.Color(0, 102, 0));
        jTextFieldquantity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldquantityActionPerformed(evt);
            }
        });
        jTextFieldquantity.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldquantityKeyTyped(evt);
            }
        });
        getContentPane().add(jTextFieldquantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 160, 108, -1));

        jDateChoosermanufacturedate.setBackground(new java.awt.Color(255, 255, 255));
        jDateChoosermanufacturedate.setForeground(new java.awt.Color(0, 102, 0));
        getContentPane().add(jDateChoosermanufacturedate, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 200, 110, 30));

        jDateChooserexpiredate.setBackground(new java.awt.Color(255, 255, 255));
        jDateChooserexpiredate.setForeground(new java.awt.Color(0, 102, 0));
        getContentPane().add(jDateChooserexpiredate, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 240, 110, 30));

        company.setBackground(new java.awt.Color(0, 102, 0));
        company.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        company.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(company, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 290, 110, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 0));
        jLabel1.setText("MANAGE MEDICINE");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 120, -1, -1));

        jLabelmedicinelist.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabelmedicinelist.setForeground(new java.awt.Color(0, 102, 0));
        jLabelmedicinelist.setText("MEDICINE LIST");
        getContentPane().add(jLabelmedicinelist, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 390, -1, -1));

        jTablemedicinelist.setForeground(new java.awt.Color(0, 102, 0));
        jTablemedicinelist.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "MED ID", "MED NAME", "MED CATAGORY", "MED PRICE", "QUANTITY", "MAN DATE", "EXPIRE DATE", "COMPANY"
            }
        ));
        jTablemedicinelist.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablemedicinelistMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTablemedicinelist);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 420, 700, 120));

        jLabelmedicinecatagory.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelmedicinecatagory.setForeground(new java.awt.Color(0, 102, 0));
        jLabelmedicinecatagory.setText("MEDICINE CATAGORY:");
        getContentPane().add(jLabelmedicinecatagory, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 250, -1, -1));

        jComboBoxmedcinecatagory.setBackground(new java.awt.Color(0, 102, 0));
        jComboBoxmedcinecatagory.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jComboBoxmedcinecatagory.setForeground(new java.awt.Color(255, 255, 255));
        jComboBoxmedcinecatagory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxmedcinecatagoryActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBoxmedcinecatagory, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 250, 110, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 0)));

        jButtonclear.setBackground(new java.awt.Color(0, 102, 0));
        jButtonclear.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonclear.setForeground(new java.awt.Color(255, 255, 255));
        jButtonclear.setText("CLEAR");
        jButtonclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonclearActionPerformed(evt);
            }
        });

        jButtonupdate.setBackground(new java.awt.Color(0, 102, 0));
        jButtonupdate.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonupdate.setForeground(new java.awt.Color(255, 255, 255));
        jButtonupdate.setText("UPDATE");
        jButtonupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonupdateActionPerformed(evt);
            }
        });

        jButtonadd.setBackground(new java.awt.Color(0, 102, 0));
        jButtonadd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonadd.setForeground(new java.awt.Color(255, 255, 255));
        jButtonadd.setText("ADD");
        jButtonadd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonaddMouseClicked(evt);
            }
        });
        jButtonadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonaddActionPerformed(evt);
            }
        });

        jButtondelete.setBackground(new java.awt.Color(0, 102, 0));
        jButtondelete.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtondelete.setForeground(new java.awt.Color(255, 255, 255));
        jButtondelete.setText("DELETE");
        jButtondelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtondeleteMouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 0));
        jLabel2.setText("X");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel3.setBackground(new java.awt.Color(0, 102, 0));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 0));
        jLabel3.setText("Back");
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButtonadd, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(jButtonupdate, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addComponent(jButtondelete, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(jButtonclear)
                .addGap(99, 99, 99))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(394, 394, 394)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3))
                    .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 226, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonclear)
                    .addComponent(jButtonupdate)
                    .addComponent(jButtonadd, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtondelete))
                .addGap(170, 170, 170))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 550));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldmedicineidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldmedicineidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldmedicineidActionPerformed

    private void jTextFieldquantityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldquantityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldquantityActionPerformed

    private void jButtonupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonupdateActionPerformed

        if (jTextFieldmedicineid.getText().isEmpty() || jTextFieldmedicinenmae.getText().isEmpty() || jTextFieldmedicineprice.getText().isEmpty() || jTextFieldquantity.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Missing information.");
        } else {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date = sdf.format(jDateChoosermanufacturedate.getDate());
            String date1 = sdf.format(jDateChooserexpiredate.getDate());
            try {
             
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", "");
                String UpdateQuery = "Update pharmacy.admin set MEDNAME='" + jTextFieldmedicinenmae.getText()+"'"+",MEDCATAGORY='"+jComboBoxmedcinecatagory.getSelectedItem().toString()+"'"+",MEDPRICE='"+jTextFieldmedicineprice.getText()+"'"+",QUANTITY='"+jTextFieldquantity.getText()+"'"+",MANDATE='"+date+"'"+",EXPIREDATE='"+date1+"'"+",COMPANY='"+company.getSelectedItem().toString()+"'"+"where MEDID="+jTextFieldmedicineid.getText();
                Statement smt=conn.createStatement();
                smt.executeUpdate(UpdateQuery);
                JOptionPane.showMessageDialog(this, "Updated successfully.");
                medicinelist();
            } catch (SQLException exp) {
                exp.printStackTrace();
            }

        }
    }//GEN-LAST:event_jButtonupdateActionPerformed

    private void jButtonaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonaddActionPerformed

        try {
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/pharmacy", "root", "");
            String query = "INSERT INTO `admin`(`MEDID`, `MEDNAME`, `MEDCATAGORY`, `MEDPRICE`, `QUANTITY`, `MANDATE`, `EXPIREDATE`, `COMPANY`) VALUES (?, ?, ?, ?, ?, ? ,? ,?)";
            pst = conn.prepareStatement(query);
            pst.setString(1, jTextFieldmedicineid.getText());
            pst.setString(2, jTextFieldmedicinenmae.getText());
            pst.setString(3, String.valueOf(jComboBoxmedcinecatagory.getSelectedItem()));
            pst.setString(4, jTextFieldmedicineprice.getText());
            pst.setString(5, jTextFieldquantity.getText());
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date = sdf.format(jDateChoosermanufacturedate.getDate());
            String date1 = sdf.format(jDateChooserexpiredate.getDate());
            pst.setString(6, date);
            pst.setString(7, date1);
            pst.setString(8, String.valueOf(company.getSelectedItem()));
            int row = pst.executeUpdate();
            medicinelist();
            conn.close();
           
            JOptionPane.showMessageDialog(null, "successfully added.");
        } catch (SQLException exp) {
            JOptionPane.showMessageDialog(null, exp);
        }
    }//GEN-LAST:event_jButtonaddActionPerformed

    private void jButtonclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonclearActionPerformed
        // TODO add your handling code here:
        jTextFieldmedicineid.setText(null);
        jTextFieldmedicinenmae.setText(null);
        jComboBoxmedcinecatagory.setSelectedItem(null);
        jTextFieldmedicineprice.setText(null);
        jTextFieldquantity.setText(null);
        jDateChoosermanufacturedate.setDate(null);
        jDateChooserexpiredate.setDate(null);
        company.setSelectedItem(null);


    }//GEN-LAST:event_jButtonclearActionPerformed

    private void jButtondeleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtondeleteMouseClicked
        if (jTextFieldmedicineid.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter the medcine id to be deleted.");
        } else {
            try {
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy", "root", "");
                String MEDID = jTextFieldmedicineid.getText();
                String Query = "Delete from pharmacy.admin where MEDID=" + MEDID;
                Statement delete = conn.createStatement();
                delete.executeUpdate(Query);
                JOptionPane.showMessageDialog(this, "Deleted successfully");
                medicinelist();
                conn.close();
            } catch (SQLException exp) {
                exp.printStackTrace();
            }
        }
    }//GEN-LAST:event_jButtondeleteMouseClicked

    private void jTablemedicinelistMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablemedicinelistMouseClicked
        DefaultTableModel model = (DefaultTableModel) jTablemedicinelist.getModel();
        int Myindex = jTablemedicinelist.getSelectedRow();
        jTextFieldmedicineid.setText(model.getValueAt(Myindex, 0).toString());
        jTextFieldmedicinenmae.setText(model.getValueAt(Myindex, 1).toString());
        jComboBoxmedcinecatagory.setSelectedItem(model.getValueAt(Myindex, 2).toString());
        jTextFieldmedicineprice.setText(model.getValueAt(Myindex, 3).toString());
        jTextFieldquantity.setText(model.getValueAt(Myindex, 4).toString());
        medicinelist();

    }//GEN-LAST:event_jTablemedicinelistMouseClicked

    private void jComboBoxmedcinecatagoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxmedcinecatagoryActionPerformed
    }//GEN-LAST:event_jComboBoxmedcinecatagoryActionPerformed

    private void jButtonaddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonaddMouseClicked
    }//GEN-LAST:event_jButtonaddMouseClicked

    private void jTextFieldmedicinepriceKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldmedicinepriceKeyTyped
      char c = evt.getKeyChar();
      if(!Character.isDigit(c))
              {
                  evt.consume();;
              }
    }//GEN-LAST:event_jTextFieldmedicinepriceKeyTyped

    private void jTextFieldquantityKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldquantityKeyTyped
       char c = evt.getKeyChar();
      if(!Character.isDigit(c))
              {
                  evt.consume();;
              }
    }//GEN-LAST:event_jTextFieldquantityKeyTyped

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
       System.exit(0);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
      
        Adminhome obj=new Adminhome();
        obj.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel3MouseClicked

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Product().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> company;
    private javax.swing.JButton jButtonadd;
    private javax.swing.JButton jButtonclear;
    private javax.swing.JButton jButtondelete;
    private javax.swing.JButton jButtonupdate;
    private javax.swing.JComboBox<String> jComboBoxmedcinecatagory;
    private com.toedter.calendar.JDateChooser jDateChooserexpiredate;
    private com.toedter.calendar.JDateChooser jDateChoosermanufacturedate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabelcompany;
    private javax.swing.JLabel jLabelexpiredate;
    private javax.swing.JLabel jLabelmanufacturedate;
    private javax.swing.JLabel jLabelmedicinecatagory;
    private javax.swing.JLabel jLabelmedicineid;
    private javax.swing.JLabel jLabelmedicinelist;
    private javax.swing.JLabel jLabelmedicinename;
    private javax.swing.JLabel jLabelmedicineprice;
    private javax.swing.JLabel jLabelquantity;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTablemedicinelist;
    private javax.swing.JTextField jTextFieldmedicineid;
    private javax.swing.JTextField jTextFieldmedicinenmae;
    private javax.swing.JTextField jTextFieldmedicineprice;
    private javax.swing.JTextField jTextFieldquantity;
    private javax.swing.JLabel logo;
    // End of variables declaration//GEN-END:variables

}
